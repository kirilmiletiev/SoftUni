﻿namespace Eventures.Web.ViewModels.Orders
{
    public class AllOrdersViewModel
    {
        public string EventName { get; set; }

        public string CustomerName { get; set; }

        public string OrderedOn { get; set; }
    }
}
