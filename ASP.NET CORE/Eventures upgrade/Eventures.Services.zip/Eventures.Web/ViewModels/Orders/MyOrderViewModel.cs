﻿namespace Eventures.Web.ViewModels.Orders
{
    public class MyOrderViewModel
    {
        public string EventName { get; set; }

        public string Start { get; set; }

        public string End { get; set; }

        public int Tickets { get; set; }
    }
}