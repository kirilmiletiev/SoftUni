﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P02_DatabaseFirst
{
    public class Configuration
    {
        public static string configurationString = "Server=DESKTOP-8KI8MHA\\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}
