﻿using System;
using System.Collections.Generic;
using System.Text;


public class Engine
{
    public int Speed;
    public int Power;

    public Engine(int speed, int power)
    {
        this.Speed = speed;
        this.Power = power;
    }
}