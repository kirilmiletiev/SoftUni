﻿using System;

class Program
{
    static void Main(string[] args)
    {
       // Random rnd = new Random();

        RandomList rnd = new RandomList();
        rnd.Add("pesho");
        rnd.Add("gosho");
        rnd.Add("Ivan");
        rnd.RemoveRandomElemnt(rnd);

    }
}