﻿using System;


class Program
{
    static void Main(string[] args)
    {
        MathOperations mo = new MathOperations();
        Console.WriteLine(mo.Add(2,3));
    }
}