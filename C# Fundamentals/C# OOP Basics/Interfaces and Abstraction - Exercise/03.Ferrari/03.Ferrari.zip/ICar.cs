﻿public interface ICar
{
     string Model { get; set; }
     string Name { get; set; }
     string Brake { get; set; }
     string Gas { get; set; }
    
}