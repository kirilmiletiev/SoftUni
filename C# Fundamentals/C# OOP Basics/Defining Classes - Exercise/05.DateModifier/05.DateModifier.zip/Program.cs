﻿using System;


class Program
{
    static void Main(string[] args)
    {
        var startData = (Console.ReadLine());
        var stopData = (Console.ReadLine());

        var b= new DateModifier(startData,stopData);

    }
}
