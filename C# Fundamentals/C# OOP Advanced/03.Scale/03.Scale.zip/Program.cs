﻿using System;

namespace _03.Scale
{
    class Program
    {
        static void Main(string[] args)
        {
            //var test = new Scale<string>("1", "233232");
            //Console.WriteLine(test.GetHeavier());
        }
    }
}
