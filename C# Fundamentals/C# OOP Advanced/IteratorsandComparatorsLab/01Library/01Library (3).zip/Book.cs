﻿using System;
using System.Collections.Generic;
using System.Text;


//public class Book : IComparable<Book>
//{
//    public string Title { get; set; }
//    public int Year { get; set; }
//    public IReadOnlyList<string> Authors { get; set; }

//    public Book(string title, int year, params string[] authors)
//    {
//        this.Title = title;
//        this.Year = year;
//        this.Authors = authors;
//    }

//    public int CompareTo(Book other)
//    {
//        int result =  this.Title.CompareTo(other.Title);
//        if (result==0)
//        {
//            result = this.Year.CompareTo(other.Year);
//        }

//        return result;
//        //if (ReferenceEquals(this, other)) return 0;
//        //if (ReferenceEquals(null, other)) return 1;
//        //var titleComparison = string.Compare(Title, other.Title, StringComparison.Ordinal);
//        //if (titleComparison != 0) return titleComparison;
//        //return Year.CompareTo(other.Year);
//    }

//    public override string ToString()
//    {
//        return $"{this.Title} - {this.Year}";

//    }
//}
public class Book : IComparable<Book>
{
    public Book(string title, int year, params string[] authors)
    {
        this.Title = title;
        this.Year = year;
        this.Authors = new List<string>();
        foreach (var author in authors)
        {
            this.Authors.Add(author);
        }
    }

    public string Title { get; protected set; }
    public int Year { get; protected set; }
    public IList<string> Authors { get; protected set; }

    public int CompareTo(Book other)
    {
        int result = this.Year.CompareTo(other.Year);
        if (result == 0)
        {
            result = this.Title.CompareTo(other.Title);
        }

        return result;
    }

    public override string ToString()
    {
        return $"{this.Title} - {this.Year}";
    }
}