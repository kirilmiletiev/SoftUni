﻿using System;
using System.Collections.Generic;
using System.Text;
using KingsGambit.Interfaces;

namespace KingsGambit
{
    public class Footman : IKillable
    {
        public Footman(string name)
        {
            this.Name = name;
            this.IsAlive = true;
        }


        public string Name { get;  set; }

        public string TheKingIsUnderAttack()
        {
            return $"Footman {this.Name} is panicking!";
        }

     
        public bool IsAlive { get;  set; }

        public void Kill(string name)
        {
            this.IsAlive = false;
        }
    }
}
