﻿using System;
using System.Collections.Generic;
using System.Text;
using KingsGambit.Interfaces;

namespace KingsGambit
{
    public class RoyalGuard : IKillable
    {
        public RoyalGuard(string name)
        {
            this.Name = name;
            this.IsAlive = true;
        }

        public string Name { get; set; }

        public string TheKingIsUnderAttack()
        {
            return $"Royal Guard {this.Name} is defending!";
        }

        public bool IsAlive { get; set; }

        public void Kill(string name)
        {
            this.IsAlive = false;
        }
    }
}
