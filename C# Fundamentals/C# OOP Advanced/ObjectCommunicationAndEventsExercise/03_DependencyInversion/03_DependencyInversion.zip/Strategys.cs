﻿namespace P03_DependencyInversion
{
    public enum Strategys
    {
       add, substract, divide, multiplicate

    }
}