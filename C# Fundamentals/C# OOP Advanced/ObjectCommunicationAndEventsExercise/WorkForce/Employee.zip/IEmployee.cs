﻿public interface IEmployee
{

    string Name { get; }

    int WorkHoursPerWeek { get; }
}