﻿using System;

namespace _01Library
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
