﻿using System.Collections;

public interface IBoxable<T>
{
     T Type { get; set; }
}