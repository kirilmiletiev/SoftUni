﻿using System;
using System.Collections.Generic;
using System.Text;

public class Happy : Mood
{
    public Happy(int happinessPoints) : base(happinessPoints)
    {
    }
}
