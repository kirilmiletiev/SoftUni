﻿using System;
using System.Collections.Generic;
using System.Text;

public class Lembas : Food
{
    private const int PointsOfHappiness = 3;

    public Lembas() : base(PointsOfHappiness)
    {
    }
}