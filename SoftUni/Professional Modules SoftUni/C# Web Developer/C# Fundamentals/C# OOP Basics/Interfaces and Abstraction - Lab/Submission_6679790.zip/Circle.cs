﻿using System;
using System.Collections.Generic;
using System.Text;

public class Circle : IDrawable
{

    private int radius;
    public int Radius
    {
        get { return radius; }
        private set { radius = value; }
    }

    public Circle(int radius)
    {
        this.Radius = radius;
    }

    public void Draw()
    {
        double rIN = this.Radius - 0.4;
        double rOut = this.Radius + 0.4;

        for (double y = this.Radius; y >= -this.Radius; y--)
        {
            for (double z = -this.Radius; z < rOut; z += 0.5)
            {
                double value = z * z + y * y;
                if (value >= rIN * rIN && value <= rOut * rOut)
                {
                    Console.Write("*");
                }
                else
                {
                    Console.Write(" ");
                }
            }
            Console.WriteLine();
        }
    }
}