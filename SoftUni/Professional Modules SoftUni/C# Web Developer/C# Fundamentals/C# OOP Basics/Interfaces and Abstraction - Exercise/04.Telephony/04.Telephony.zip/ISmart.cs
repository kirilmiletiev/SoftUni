﻿
public interface ISmart
{
    string Browse(string url);
}