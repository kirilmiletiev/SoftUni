﻿
public interface IPhone
{
    string Call(string phoneNumber);
    string Model { get; }
}