﻿ using System.Runtime.InteropServices.ComTypes;

public interface IBirthdate
{
     string Birthdate { get; set; }
}