﻿
public interface IControl
{
     string Id { get; set; }
}