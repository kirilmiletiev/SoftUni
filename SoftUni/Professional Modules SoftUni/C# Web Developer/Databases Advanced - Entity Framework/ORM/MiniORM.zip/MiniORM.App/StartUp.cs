﻿namespace MiniORM.App
{

	public class StartUp
	{
		public static void Main(string[] args)
		{
            Engine.Run();
			
		}
	}
}