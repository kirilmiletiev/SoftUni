﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniORM.App.Data.Entities
{
   public class Configuration
    {

        public const string connectionString = @"Server=DESKTOP-8KI8MHA\SQLEXPRESS;Database=MiniORM;Integrated Security=True";
        
    }
}
