﻿namespace IRunes.App.ViewModels
{
    public class AlbumCreateViewModel
    {
        public string Name { get; set; }

        public string Cover { get; set; }
    }
}