﻿namespace IRunes.App.ViewModels
{
    public class UserRegisterViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }

        public string Confirmpassword { get; set; }

        public string Email { get; set; }
    }
}