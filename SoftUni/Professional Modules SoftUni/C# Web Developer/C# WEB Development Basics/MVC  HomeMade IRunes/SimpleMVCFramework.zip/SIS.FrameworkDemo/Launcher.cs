﻿namespace SIS.FrameworkDemo
{
    using Framework;
    using Framework.Routers;
    using WebServer;

    public class Launcher
    {
        public static void Main()
        {
            //var handlers = new HttpHandlerContextRouter(new ControllerRouter(), new ResourceRouter());
            //var server = new Server(8080, handlers);

            //MvcEngine.Run(server);
        }
    }
}