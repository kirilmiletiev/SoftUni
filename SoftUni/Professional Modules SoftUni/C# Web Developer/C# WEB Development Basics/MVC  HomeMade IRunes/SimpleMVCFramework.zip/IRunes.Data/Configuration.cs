﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IRunes.Data
{
    public static class Configuration
    {
        public static readonly string ConnectionString =
            @"Server=DESKTOP-8KI8MHA\SQLEXPRESS;Database=IRunes;Integrated Security=True;";
    }
}
